package com.yunnaaoi.mdwidget;

import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class WidgetStartConfigure extends AppCompatActivity {
    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_layout);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null ) {
            appWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        }

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }

        Button saveButton = findViewById(R.id.save_button);
        saveButton.setOnClickListener(v -> {
            String note = "Path/to/vault";
            String color = "#0f0f12";

            WidgetPreference.saveSettings(this, appWidgetId, "note", note);
            WidgetPreference.saveSettings(this, appWidgetId, "color", color);

            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this);
            WidgetMD.updateAppWidget(this, appWidgetManager, appWidgetId);

            Intent resultValue = new Intent();
            resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
            setResult(RESULT_OK, resultValue);
            finish();
        });
    }
}
