package com.yunnaaoi.mdwidget;

import android.content.Context;
import android.content.SharedPreferences;

public class WidgetPreference {
    private static final String PREF_NAME = "widget_prefs";
    public static void saveSettings(Context context, int appWidgetId, String key, String value) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(key + "_" + appWidgetId, value).apply();
    }

    public static String loadSettings(Context context, int appWidgetId, String key, String defaultValue) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getString(key+"_"+appWidgetId, defaultValue);
    }

    public static void removeSettingsForWidget(Context context, int appWidgetId) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

    }
}
